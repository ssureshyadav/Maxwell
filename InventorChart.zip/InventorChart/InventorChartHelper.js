({
    doInit : function(component, event, helper) 
    {
        console.log(component.get("v.recordId"));
        console.log('check Record Id:::'+component.get("v.recordId") == '');
        if(component.get("v.recordId") == ''){
            return false;
        }
        if(component.get("v.recordId") != '' && component.get("v.recordId") != undefined && component.get("v.recordId") != null) //Added on 8/7/2020 to resolve the component error - APPL500
        {
            component.set("v.showSpinner",true);
            var action = component.get("c.fetchInvestorsBYInventionDisclosure"); 
            action.setParams({'recordId':component.get("v.recordId")});
            action.setCallback(this, function(response) { 
                var state = response.getState(); 
                //alert(state);
                if (state === "SUCCESS") { 
                    
                    var dataObj= response.getReturnValue(); 
                    
                    component.set("v.Responsedata",dataObj.chartData);
                    console.log(dataObj.mapinventors);
                    component.set("v.InventorMap",dataObj.mapinventors);
					console.log(component.get("v.InventorMap"));                    
                    
                    const inventorMap=dataObj.mapinventors;
                    var inventorRecords=[];
                    var duplicatecheck=[];
                    //var mapInventors=[];
                    let recordscount=0;
                    var arrayValue=[];
                    //console.log(Object.keys(inventorMap));
                    Object.keys(inventorMap).forEach(function(key) {
                        //console.log('Records:'+inventorMap[key]);
                        recordscount +=inventorMap[key].length;
                        arrayValue.push({'Name': key,'value':inventorMap[key].length});    
                        inventorMap[key].forEach(function(entry) {
                            if(entry != null){
                                //mapInventors.push({"key" :key, "value" : entry});
                                if(duplicatecheck.indexOf(entry.Name)==-1){
                                    duplicatecheck.push(entry.Name);
                            		inventorRecords.push(entry);
                                }
                            }
                        });
                    });
                    //component.set("v.InventorMap",mapInventors);
                    component.set("v.InventionDisclosureRecords",inventorRecords);
                    
                    component.set("v.recordsCount",recordscount);
                    
                    component.set("v.Inventors",arrayValue);
                    //console.log(inventorRecords);
                    
                    //helper.piechart(component,event,helper);
                    component.set("v.showSpinner",false);
                    
                    //
                    
                } 
            });
            $A.enqueueAction(action);
        }
        
    },
    piechart : function(component,event,helper) {
        var jsonData = component.get("v.Responsedata");
        var dataObj = JSON.parse(jsonData);
        console.log('piechart::'+dataObj);
        new Highcharts.Chart({
            chart: {
                marginRight: 120,
                renderTo: component.find("chart").getElement(),
                type: 'pie',
                options3d: {
                    enabled: true,
                    alpha: 45
                }
            },
            legend: {
                align: 'right',
                layout: 'vertical',
                verticalAlign: 'middle',
                padding: 1,
                itemDistance: 50,
                itemMarginTop: 5,
                itemMarginBottom: 5,
                alignColumns:true,
                layout: 'proximate',
                itemStyle: {
                    color: 'grey',
                    fontFamily: 'sans-serif',
                    verticalalign:'top'
                },
                itemHoverStyle: {
                    color: '#FF0000',
                    border:"2",
                },
                //symbolPadding: -150,
                //labelFormat: '{point.name}: {point.y}',
                x: -100,
                y: 100
            },
            title: {
                text: component.get("v.recordsCount"),
                verticalAlign: 'middle',
                x: -55,
                y: 20,
                style: {
                    fontFamily: 'Salesforce Sans',
                    fontsize: '12px',
                    fontWeight: 'bold'
                },
                floating: true,
            },
            xAxis: {
                categories: component.get("v.xAxisCategories"),
                crosshair: true
            },
            yAxis: {
                min: 0,
                title: 
                {
                    text: component.get("v.yAxisParameter")
                }
            },
            plotOptions: {
                series: {
                    events: {
                        click: function(e) {
                            console.log(e.point.name);
                            helper.displayUserRecords(component,event,e.point.name);
                        },
                    },
                },
                pie: {
                    shadow: false,
                    size: '90%',
        			innerSize: '60%',
                    depth: 90,
                    center: ['50%', '50%'],
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        shadow: false,
                        style: {
                            fontFamily: 'Salesforce Sans',
                            fontsize: '12px',
                            fontweight: '400',
                            color:'white',
                            textShadow:false,
                            textOutline: 0,
                        },
                        distance: -25,
                        format: '{point.y}',
                    },
                    showInLegend: true,                    
                    //depth: 45 
                    point: {
                        events: {
                            legendItemClick: function (e) {
                                this.slice();
                                console.log(e.point);
                                console.log(">>>>", e.target.options);
                                console.log(">>>>", e.target.options.name);
                                helper.displayUserRecords(component,event,e.target.options.name);
                                return false;
                            }
                        }
                    },
                }
            },
            series: [{
                type: 'pie',
                name:'Count',
                data:dataObj,
                innerSize: '50%',
                sliced: true
            }]
            
        });
        
    },
    
    displayUserRecords : function(component, event, username) {
        component.set("v.showSpinner",true);
        
        console.log(component.get("v.InventorMap"));
        const inventorMap=component.get("v.InventorMap");
        var isSameUser =false;
        if(component.get("v.priorSelectedValue") == username){
            isSameUser =true;
            component.set("v.priorSelectedValue","");
        }else{
            component.set("v.priorSelectedValue",username);
        } 
        console.log(inventorMap.length);
        console.log('displayUserRecords::'+username);
        let inventorRecords=[];
        var duplicatecheck=[];
        if(username != null){
            if(isSameUser){
				Object.keys(inventorMap).forEach(function(key) {
                        inventorMap[key].forEach(function(entry) {
                            if(duplicatecheck.indexOf(entry.Name)==-1){
                                duplicatecheck.push(entry.Name);
                                inventorRecords.push(entry);
                            }
                        });
                }); 
            }else {
                Object.keys(inventorMap).forEach(function(key) {
                    console.log('Records:'+inventorMap[key]);
                    if(key == username){
                        inventorMap[key].forEach(function(entry) {
                            if(duplicatecheck.indexOf(entry.Name)==-1){
                                duplicatecheck.push(entry.Name);
                                inventorRecords.push(entry);
                            }
                            
                        });
                    }
                });
			}
            console.log(inventorRecords);
            component.set("v.InventionDisclosureRecords",inventorRecords);
        }
        component.set("v.showSpinner",false);
	},
    
    sortBy: function (field, reverse, primer) {
        var key = primer ?
            function(x) {return primer(x[field])} :
            function(x) {return x[field]};
        //reverse = !reverse ? 1 : -1;
        return function (a, b) {
            return a = key(a)?key(a):'', b = key(b)?key(b):'', reverse * ((a > b) - (b > a));
        }
    },
})