({
    doInit : function(component, event, helper) {
        //helper.getThisReconciliation(component, helper);
        var cols = [
                        {label: 'Docket No', fieldName: 'Name', type: 'text',sortable: true},
                        {label: 'Title', fieldName: 'Title', type: 'text',sortable: true},
                        {label: 'Disclosure Status', fieldName: 'DisclosureStatus',sortable: true},
                        {label: 'Final Decision', fieldName: 'Final_Decision',sortable: true},
                        {label: 'Business value score', fieldName: 'BusinessValueScoreNew',sortable: true, type: 'number', typeAttributes: { maximumFractionDigits: '2' }},
                        {label: 'Leverage value score', fieldName: 'LeverageValueScoreNew',sortable: true, type: 'number', typeAttributes: { maximumFractionDigits: '2' }},
                        {label: 'Market value score', fieldName: 'OverallScore',sortable: true, type: 'number', typeAttributes: { maximumFractionDigits: '2' }},
                        {label: 'Docket Number(Patent)', fieldName: 'PatentDocketNo',sortable: true},
                        {label: 'Application Complexity', fieldName: 'ApplicationComplexity',sortable: true},
                        {label: 'Primary Inventor contact', fieldName: 'PrimaryInventorName',sortable: true},
                        {label: 'Project Name', fieldName: 'ProjectCodeName',sortable: true},
                        {label: 'Responsible Attorney', fieldName: 'InternalCounsel',sortable: true},
                        {label: 'OC Firm', fieldName: 'OCFirm',sortable: true},
                        {label: 'Inventors', fieldName: 'AllInventors',sortable: true},            
                    ];
		component.set("v.tableCols", cols);
		helper.doInit(component,event,helper);
    },
    
    /*afterScriptsLoaded : function(component, event, helper) 
    {
        helper.doInit(component,event,helper);
    },*/
    
    handleshowchart : function(component, event, helper) 
    {
        component.set("v.showChart", true);
        $A.util.removeClass(component.find("chart"), "toggle");
        helper.piechart(component,event,helper);
    },
    
    handlehidechart : function(component, event, helper) 
    {
        component.set("v.showChart", false);
        $A.util.addClass(component.find("chart"), "toggle");
    },
            
	handleNameClick : function(component, event, helper) {
            var inventorName=event.getSource().get("v.label");
            console.log(inventorName);
            console.log(component.get("v.InventorMap"));
            helper.displayUserRecords(component,event,inventorName);
	},
        
	handleSort: function(component, event, helper) {
        var sortedBy = event.getParam('fieldName');
        var sortDirection = event.getParam('sortDirection');
            
		console.log(sortedBy);
		console.log(sortDirection);

        var cloneData = component.get("v.InventionDisclosureRecords");
        cloneData.sort((helper.sortBy(sortedBy, sortDirection === 'asc' ? 1 : -1)));
        
        component.set('v.InventionDisclosureRecords', cloneData);
        component.set('v.sortDirection', sortDirection);
        component.set('v.sortedBy', sortedBy);
    },
            
	downloadCSV : function(component, event, helper) {
            component.set("v.loadedData",true);
        var gridDataHeaders = component.get("v.tableCols");
		//console.log(gridDataHeaders);
        var gridDataRows = component.get("v.InventionDisclosureRecords");
		//console.log(gridDataRows);
		var csv = '';
		var headers=[];
        for(var i = 0; i < gridDataHeaders.length; i++){         
            headers.push(gridDataHeaders[i]["fieldName"]);
            csv += (i === (gridDataHeaders.length - 1)) ? gridDataHeaders[i]["label"] : gridDataHeaders[i]["label"] + ','; 
        }
        csv += "\n";
        var data = [];
        console.log(gridDataRows.length);
        
    	for(var i = 0; i < gridDataRows.length; i++){
			var gridRowIns = gridDataRows[i];                          
            var tempRow = [];
            for(var j=0;j<headers.length;j++){
                var tempValue = '';
                tempValue += gridRowIns[headers[j]];
                if(tempValue.includes(',')){
                	tempValue = "\"" + tempValue + "\"";
                }
                tempValue =(tempValue =='undefined'?'':tempValue);
                tempValue = tempValue.replace(/(\r\n|\n|\r)/gm,"");                 
                tempRow.push(tempValue);
            }
            data.push(tempRow); 
    	}
        
        
        data.forEach(function(row){
            csv += row.join(',');
            csv += "\n";
        });
        //console.log(csv);
        //console.log(encodeURI(csv));
        var action = component.get("c.downloadCsv"); 
            action.setParams({'csvString':csv});
            action.setCallback(this, function(response) { 
                component.set("v.loadedData",false);
                var state = response.getState(); 
                if (state === "SUCCESS") { 
                    window.open(response.getReturnValue());
                } 
            });
            $A.enqueueAction(action);
        
        /*var hiddenElement = document.createElement('a');
        hiddenElement.href = 'data:text/csv;charset=utf-8,' + csv;
        hiddenElement.target = '_blank';
        hiddenElement.download = 'IDFs_Inventor count.csv'; 
        hiddenElement.click();*/
    }
})