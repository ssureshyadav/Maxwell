({
    loadValuesController : function (component,event,helper) 
    {
        $(document).ready(function(){
            jQuery.fn.highlight = function(pat) {
                function innerHighlight(node, pat) {
                    var skip = 0;
                    if (node.nodeType == 3) {
                        var pos = node.data.toUpperCase().indexOf(pat);
                        pos -= (node.data.substr(0, pos).toUpperCase().length - node.data.substr(0, pos).length);
                        if (pos >= 0) {
                            var spannode = document.createElement('span');
                            spannode.className = 'highlight';
                            var middlebit = node.splitText(pos);
                            var endbit = middlebit.splitText(pat.length);
                            var middleclone = middlebit.cloneNode(true);
                            spannode.appendChild(middleclone);
                            middlebit.parentNode.replaceChild(spannode, middlebit);
                            skip = 1;
                        }
                    }
                    else if (node.nodeType == 1 && node.childNodes && !/(script|style)/i.test(node.tagName)) {
                        for (var i = 0; i < node.childNodes.length; ++i) {
                            i += innerHighlight(node.childNodes[i], pat);
                        }
                    }
                    return skip;
                }
                return this.length && pat && pat.length ? this.each(function() {
                    innerHighlight(this, pat.toUpperCase());
                }) : this;
            };
            
            
        });//doc.ready
        
    },
    
	doinit : function(component, event, helper) {
        /*var UserName =  $A.get("$SObjectType.CurrentUser.Email");
        console.log(UserName);
        
         var User =  $A.get("$SObjectType.CurrentUser");
        console.log(JSON.stringify(User));*/
             component.set('v.SDOWGcolumns', [
            	{
                    type: "button-icon",
                    initialWidth: 60,
                    label: '',
                    typeAttributes:{
                        iconName: 'utility:delete',
                        name: 'DeleteRow',
                        title: 'Delete',
                        value: 'Delete',
                        variant: 'bare',
                        iconPosition: 'center',
                        class:'removeFromDataTable'
                    }
                },
            	
            	{label: 'Title', fieldName: 'Title', type: 'text',sortable: true},
                {label: 'Alias', fieldName: 'Alias', type: 'text',sortable: true},
            	{label: 'Status', fieldName: 'Status', type: 'text',sortable: true},
            	{label: 'SDOWG ID', fieldName: 'Name', type: 'text',sortable: true},
            	{label: 'SDO', fieldName: 'SDO', type: 'text',sortable: true},
                {label: 'WG IP Policy', fieldName: 'IPPolicy', type: 'text',sortable: true},
                {label: 'WG Participant Count', fieldName: 'WGParticipanCount', type: 'text',sortable: true},
                {label: 'SDOWG Active Participants', fieldName: 'ActiveParticipants', type: 'text',sortable: true},
            ]);
        
        /*
         {label: 'SDO Working Group URL', fieldName: 'SDO_Working_Group_URL', type: 'text',sortable: true},
         */

		component.set('v.Participantscolumns', [
            	{
                                type: "button-icon",
                                initialWidth: 60,
                                //label: 'Action',
                                fixedWidth:30,
                                typeAttributes:{
                                    iconName: 'utility:delete',
                                    //IconDisplayedDelete
                                    
                                    name: 'DeleteRow',
                                    //title: 'Delete',
                                    title: {
                                        fieldName: 'tooltipDelete'
                                    },
                                    value: 'Delete',
                                    variant: 'bare',
                                    iconPosition: 'right',
                                    //disabled: {fieldName:'IsPrimaryInventor'},
                                }
                                
                            },
                            
                            {
                                type: "button-icon",
                                fixedWidth:20,typeAttributes:{
                                    iconName: 'utility:edit',
                                    
                                    name: 'editrow',
                                    //title: 'Edit',
                                    title: {
                                        fieldName: 'tooltipEdit'
                                    },
                                    value: 'Edit',
                                    variant: 'bare',
                                    iconPosition: 'right',
                                    //disabled: {fieldName:'IsPrimaryInventor'},
                                }
                            },
            	{label: 'Name', fieldName: 'Name', type: 'text',sortable: true},
            	{label: 'Email', fieldName: 'Email', type: 'text',sortable: true},
                {label: 'Country', fieldName: 'Location', type: 'text',sortable: true},
                {label: 'Secondary Email', fieldName: 'Secondary_Email', type: 'text',sortable: true},
                {label: 'Formal Name', fieldName: 'Preferred_Name', type: 'text',sortable: true},
                {label: 'Citizenship', fieldName: 'Citizenship', type: 'text',sortable: true},
                {label: 'Client Group', fieldName: 'Client_Group', type: 'text',sortable: true},
                {label: 'Eligible for Award', fieldName: 'IsEligible_for_Inventor_Award', type: 'text',sortable: true},
                {label: 'Role Type ', fieldName: 'Role_Type', type: 'text',sortable: true},
            	{label: 'Leadership Position ', fieldName: 'Leadership_Position', type: 'text',sortable: true},
                {label: 'Participant Status', fieldName: 'Participant_Status', type: 'text',sortable: true},
                {label: 'DS Person Id', fieldName: 'DSID_External', type: 'text',sortable: true},
                ]);

        var action = component.get("c.getRequiredInfo");
        action.setCallback(this, function(response){
            var state = response.getState();
            var result = response.getReturnValue();
            console.log(result);
            if (state === "SUCCESS") 
            {
                component.set("v.UserName",result.userName);
                component.set("v.hasAccess",result.hasAccess);
                if(result.person != ''){
                	component.set("v.Person",result.person);
                    component.set("v.pInventor",result.person.Id);
                    
                    component.set("v.attorney",result.attorneyId);
                    component.set("v.IPManager",result.IPManager);
                    component.set("v.clientGroup",result.clientGroup);
                    
                }
                component.set("v.StandardsAdmin",result.standardAdminId);
                component.set("v.SDO",result.lstSDO);
                component.set("v.defaultSDO",result.selectedSDO);
                component.set("v.SDOTechnical",result.lstSDOTechnical);
                
                component.set("v.SDOWGSelect","SubSet");
                
                component.set("v.initLoaded",true);
                //component.set("v.SDOWG",result.lstSDOWG);
            }
        });
        $A.enqueueAction(action);
        
        
        if(component.get("v.recordId") != null){
            component.set("v.initLoaded",true);
			var action = component.get("c.fetchStandardsRequestInfo");
            action.setParams({'recordId': component.get("v.recordId")});
            action.setCallback(this, function(response){
                var state = response.getState();
                var result = response.getReturnValue();
                console.log(result);
                if (state === "SUCCESS") 
                {
                    console.log(JSON.stringify(result));
                    component.set("v.displayInfo",true);
                    var standardRequest=result.standardRequest;
                    helper.displayFields(component,standardRequest.Request_Type__c);
                    //component.set("v.pInventor",standardRequest.Primary_Contact__c);
                    component.set("v.RequestName",standardRequest.Name);
                    component.set("v.ImplementProductService",standardRequest.Implement_Product_Service__c);
                    component.set("v.approver",standardRequest.Approver_Name__c);
                    
                    component.set("v.ManagementApproval",standardRequest.Management_Approval__c);
                    component.set("v.TechnologyAreaInventions",standardRequest.Technology_Area_Inventions__c);
                    component.set("v.TechnicalContribution",standardRequest.Technical_Contribution__c);
                    component.set("v.LeadershipConflict",standardRequest.Leadership_Conflict__c);
                    component.set("v.LeadershipWorkingGroup",standardRequest.Leadership_Working_Group__c);
                    component.set("v.LegalCoverage",standardRequest.Legal_Coverage__c);
                    component.set("v.SDOIndemnification",standardRequest.SDO_Indemnification__c);
                    component.set("v.JointCompanySubmission",standardRequest.Joint_Company_Submission__c);
                    if(standardRequest.SDOWG_Select__c != null && standardRequest.SDOWG_Select__c != ''){
                    	component.set("v.SDOWGSelect",standardRequest.SDOWG_Select__c);
                    }
                    component.set("v.SDOWGSelect1",standardRequest.New_SDO_WG__c);
                    component.set("v.MonitorMailingLists",standardRequest.Monitor_Mailing_Lists__c);
                    
                    
                    if(standardRequest.Management_Approval__c == 'Yes'){
                        component.set("v.displayApprovers",true);
                    }
                    
                    if(standardRequest.Motivation__c != '' && standardRequest.Motivation__c != null && standardRequest.Motivation__c != undefined){
                        var motivation=standardRequest.Motivation__c.split(';');
                        var motivations=[];
                        for(var i=0;i<motivation.length;i++){
                            motivations.push(motivation[i]);
                        }
                        component.set("v.Motivations",motivations);
                    }
                    
                    if(standardRequest.Membership_Level__c != '' && standardRequest.Membership_Level__c != null && standardRequest.Membership_Level__c != undefined){
                        var motivation=standardRequest.Membership_Level__c.split(';');
                        var motivations=[];
                        for(var i=0;i<motivation.length;i++){
                            motivations.push(motivation[i]);
                        }
                        component.set("v.MembershipLevel",motivations);
                    }
                    
                    if(standardRequest.Leadership_Position__c != '' && standardRequest.Leadership_Position__c != null && standardRequest.Leadership_Position__c != undefined){
                        var motivation=standardRequest.Leadership_Position__c.split(';');
                        var motivations=[];
                        for(var i=0;i<motivation.length;i++){
                            motivations.push(motivation[i]);
                        }
                        component.set("v.LeadershipPositions",motivations);
                    }
                    /*component.set("v.LeadershipPositions",standardRequest.);
                    component.set("v.Motivations",standardRequest.Motivation__c);*/
                    component.set("v.SelectedSDO",standardRequest.SDO__c);
                    component.set("v.SelectedSDOTechnical",standardRequest.SDO_Technical_Standard__c);
					console.log('requestWorkingGroups::'+result.requestWorkingGroups);
					console.log(JSON.stringify(result.requestWorkingGroups));
					console.log(JSON.stringify(result.requestWorkingGroups.lstResult));
                    component.set("v.SDOWgroups",result.requestWorkingGroups.lstResult);
                    component.set("v.participants",result.participants);
                    component.set("v.Documents",result.lstDocuments);
                }
            });
            $A.enqueueAction(action);	
        }
        
        console.log('do init');
	},
    
    handleSDO : function(component, event, helper){
        console.log(component.get("v.SelectedSDO"));
        helper.partialSave(component);
    },
    
    handleSDOTechnical : function(component, event, helper){
        console.log(component.get("v.SelectedSDOTechnical"));
        helper.partialSave(component);
    },
    
   /* handleonLoad : function(component, event, helper) {
        var recui = event.getParam("recordUi");
        
        if(recui.record.id != null){
        	var requestType = recui.record.fields["Request_Type__c"].value;
            console.log(requestType);
            helper.displayFields(component,requestType);
		}
        
    },*/
    
    onprimarycontactchange : function(component, event, helper){
        let person =  event.getSource().get("v.value") ;
        console.log(person);
        return;
        if(person[0] != undefined){
            component.set("v.pInventor",person[0]);
        }else{
            component.set("v.pInventor","");
            component.set("v.attorney","");
        }
       
        console.log('pInventor::'+component.get("v.pInventor"));
        
        if(component.get("v.pInventor") != "" && component.get("v.pInventor") != undefined){
        	helper.populateAttorney(component);    
        }
        helper.partialSave(component);
        
    },
    
    onSDOWGSelectchange : function(component, event, helper){
        console.log(component.get("v.SDOWGSelect"));
        if(component.get("v.SDOWGSelect") == 'SubSet'){
            component.set("v.displayWorkingGroups",true);
        }else{
            component.set("v.displayWorkingGroups",false);
        }
         helper.partialSave(component);
    },
    
    onleadershipPositionsChanged : function(component, event, helper){
        var LeadershipPositions=component.get("v.LeadershipPositions");
        var LeadershipPosition='';
        for(var i=0;i<LeadershipPositions.length;i++){
            LeadershipPosition +=LeadershipPositions[i] + ';';
        }
        component.set("v.LeadershipPosition",LeadershipPosition);
        console.log(component.get("v.LeadershipPosition"));
        helper.partialSave(component);
    },
    
    onMemberShipLevelChanged : function(component, event, helper){
        var MembershipLevels=component.get("v.MembershipLevel");
        var MembershipLevel='';
        for(var i=0;i<MembershipLevels.length;i++){
            MembershipLevel +=MembershipLevels[i] + ';';
        }
        component.set("v.MembershipLevels",MembershipLevel);
        console.log(component.get("v.MembershipLevels"));
        helper.partialSave(component);
    },
    
    onMotivationChanged : function(component, event, helper){
        var Motivations=component.get("v.Motivations");
        var Motivation='';
        for(var i=0;i<Motivations.length;i++){
            Motivation +=Motivations[i] + ';';
        }
        component.set("v.Motivation",Motivation);
        console.log(component.get("v.Motivation"));
        helper.partialSave(component);
    },
    
    onManagementApprovalchange : function(component, event, helper){
        let approvalValue =  event.getSource().get("v.value") ;
        console.log(approvalValue);
        console.log(component.get("v.ManagementApproval"));
        if(approvalValue == 'Yes'){
            component.set("v.displayApprovers",true);
        }else{
            component.set("v.displayApprovers",false);
        }
        helper.partialSave(component);
    },
    
    onhandleChange : function(component, event, helper) 
    {        
        let newValue =  event.getSource().get("v.value") ; 
        console.log(newValue);
        if(newValue == ''){
            component.set("v.displayInfo",false);
            return;
        }else{
            component.set("v.displayInfo",true);
        }
        var isNew =false;
        console.log(component.get("v.recordId"));
        console.log(component.get("v.recordId") == '' || component.get("v.recordId") == undefined);
        if(component.get("v.recordId") == '' || component.get("v.recordId") == undefined){
            isNew =true;
        }
        component.set("v.RequestStatus","Draft");
        helper.displayFields(component,newValue);
        helper.partialSave(component);
        component.set("v.checkmark",true);
        console.log('isNew'+isNew);
        
        window.setTimeout(
            $A.getCallback(function() {
                component.set("v.checkmark",false);
                if(isNew && component.get("v.recordId") != undefined){
                    helper.populateInternalParticipant(component);
                }
                // component.set('v.spinner',false);
            }), 5000 
        );
    },
    
    autoSave : function(component, event, helper) 
    {
        console.log('autoSave');
        helper.partialSave(component);
    },
    onMonitorMailingListchange : function(component, event, helper) 
    {
       var valuesselected=component.get("v.MonitorMailingLists");
       // alert(valuesselected);
        if(valuesselected=='Yes'){
         component.set('v.isyesMailingLists','true'); 
        }else{
             component.set('v.isyesMailingLists','false'); 
        
        }
        helper.partialSave(component);
    },
    
    onLeadershipConflictchange: function(component, event, helper) 
    {
        helper.partialSave(component);
    },
    
    onLeadershipWorkingGroupchange: function(component, event, helper) 
    {
        console.log(component.get("v.LeadershipWorkingGroup"));
        helper.partialSave(component);
    },
    
    
    isJointCompanySubmissionYes: function(component, event, helper) 
    {
       var valuesselected=component.get("v.JointCompanySubmission");
       // alert(valuesselected);
        if(valuesselected=='Yes'){
         component.set('v.isYesJointCompanySubmission','true'); 
        }else{
             component.set('v.isYesJointCompanySubmission','false'); 
        
        }
        helper.partialSave(component);
    },
    ImplementProductServicechnage:function(component, event, helper) 
    {
       var valuesselected=component.get("v.ImplementProductService");
       // alert(valuesselected);
        if(valuesselected=='Yes'){
         component.set('v.isYesImplementProductService','true'); 
        }else{
             component.set('v.isYesImplementProductService','false'); 
        
        }
        helper.partialSave(component);
    },
    handleError : function(component, event, helper) {
         var error = event.getParam("error");
        var errorMessage = event.getParam("message");
    	console.log(error);
        
        
    },
    
    handleSuccess : function(component, event, helper) {
        var record = event.getParam("response");
        var apiName = record.apiName;
        console.log(apiName);
        var fields=record.fields;
        console.log(JSON.stringify(fields));
        //console.log('Primary_Contact__c::'+fields.Primary_Contact__c.value);
        //console.log('Internal_Due_Date__c::'+fields.Internal_Due_Date__c.value);
        //console.log('Submission_Date__c::'+fields.Submission_Date__c.value);
        console.log(component.get("v.RequestName"));
        if(component.get("v.RequestName") == undefined || component.get("v.RequestName") == ''){
            component.set("v.validate",true); 
        	component.set("v.RequestName",fields.Name.value);
            
            var timesRun = 0;
            var interval = window.setInterval(
                $A.getCallback(function() {
                    timesRun += 1;
                    if(timesRun === 5){
                        clearInterval(interval);
                    }
                    $('#divAutoSave').fadeOut(500);
                    $('#divAutoSave').fadeIn(500);
                }), 2000 
            );
        }
        var myRecordId = record.id; 
        console.log(myRecordId);
        if(!component.get("v.isPartialSave")){
            
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "type": "success",
                "title": "Success!",
                "message": "Standards Request "+component.get("v.RequestName") + " has been submitted"
            });
            toastEvent.fire();
            
            var navEvt = $A.get("e.force:navigateToSObject");
            navEvt.setParams({
              "recordId": myRecordId,
              "slideDevName": "related"
            });
            navEvt.fire();
            
            /*var action = component.get("c.generatePDF");
            action.setParams({'recordId': component.get("v.recordId")});
            action.setCallback(this, function(response){
                var state = response.getState();
            });
            $A.enqueueAction(action);*/
            
            var sendEmail = component.get("c.sendEmail");
            sendEmail.setParams({'recordId': component.get("v.recordId")});
            sendEmail.setCallback(this, function(response){
                var state = response.getState();
            });
            $A.enqueueAction(sendEmail);
            
            /*if(fields.SDO__c.value == null){
                var sendEmail = component.get("c.createSDO");
                sendEmail.setParams({'recordId': component.get("v.recordId")});
                sendEmail.setCallback(this, function(response){
                    var state = response.getState();
                });
                $A.enqueueAction(sendEmail);	
            }*/
            
            var copySDOandWGTS = component.get("c.copySDOandWGTS");
            copySDOandWGTS.setParams({'recordId': component.get("v.recordId")});
            copySDOandWGTS.setCallback(this, function(response){
                var state = response.getState();
            });
            $A.enqueueAction(copySDOandWGTS);
            
            /*if(fields.Request_Type__c.value =='Disclose Patent/IP to SDO' && fields.SDO__c.value != null){
                var sendEmail = component.get("c.copySDOandWG");
                sendEmail.setParams({'recordId': component.get("v.recordId")});
                sendEmail.setCallback(this, function(response){
                    var state = response.getState();
                });
                $A.enqueueAction(sendEmail);
            }
            
            if(fields.Request_Type__c.value =='Submit a Technical Contribution' && fields.SDO__c.value != null){
                var copySDOandWGTS = component.get("c.copySDOandWGTS");
                copySDOandWGTS.setParams({'recordId': component.get("v.recordId")});
                copySDOandWGTS.setCallback(this, function(response){
                    var state = response.getState();
                });
                $A.enqueueAction(copySDOandWGTS);
            }*/
            
        }else{
            component.set("v.recordId",myRecordId);
        }
    },
    
    SDOChanged : function(component, event, helper) {
        console.log(component.get("v.SDOselectedValue"));
        helper.partialSave(component);
    },
    
    handleCustomSave : function(component, event, helper) {
        console.log('handleSave');
        console.log(component.get("v.isPartialSave"));
        component.set("v.RequestStatus","Draft");
        var today = new Date();
        component.set("v.LastAction","Standard Request was created by " + component.get("v.UserName") + " on " + today.getDate()  + '/'+today.getMonth() + '/' + today.getFullYear());
        component.set("v.isPartialSave",false);
        //component.find('save').submit();
    },
    
    handlecustomSubmit : function(component, event, helper) {
         console.log('handlecustomSubmit');
        component.set("v.submitForm",true);
        
        var today = new Date();
        component.set('v.SubmissionDate', today.getFullYear() + '-'+(today.getMonth()+1) + '-' + today.getDate());
        var d = new Date();
		d.setDate(d.getDate() + 45);
        component.set("v.InternalDueDate",d.getFullYear() + '-'+(d.getMonth()+1) + '-' + d.getDate());
        component.set("v.LastAction","Standard Request was submitted by " +component.get("v.UserName") + " on " + today.getDate()  + '/'+(today.getMonth()+1) + '/' + today.getFullYear());
        component.set("v.RequestStatus","Attorney Review");
        component.set("v.FinalDecision","Under Review");
         //var submit = component.get("v.submitForm");
        //alert(component.get("v.attorney")+'Attorney');
        
             var action=component.get("c.DiarySignoff");
          
            action.setParams({"recordId":component.get("v.recordId"),'Action':'Request Submitted','Status':' ',
                              'Comments':component.get("v.comments"),'Attorney':component.get("v.attorney")});
        action.setCallback(this,function(response){
            console.log(response.getReturnValue());
            
          // $A.get('e.force:refreshView').fire(); 
        });
            $A.enqueueAction(action);
        
        
      

        component.set("v.isPartialSave",false);
        //component.find('save').submit();
    },
    
    handleSubmit : function(component, event, helper) {
        console.log('handleSubmit:::');
        event.preventDefault(); 
        component.set("v.errorMessage",'')
              // stop the form from submitting
        if(!component.get("v.submitForm")){
            component.set("v.submitForm",false);
            return;
        }
        console.log('Passed validation');
        var fields = event.getParam('fields');
        console.log(fields);
        console.log(JSON.stringify(fields));
        console.log(fields.Request_Type__c);
        
        if(fields.Request_Type__c == '' ||  fields.Request_Type__c == '-- Please Select one --' || fields.Request_Type__c == null || fields.Request_Type__c == undefined){
            //alert('Pelase select Request Type');
            component.set("v.errorMessage",'Please select Request Type');
            component.set("v.submitForm",false);
            return;
        }
        
        if(fields.Primary_Contact__c == null || fields.Primary_Contact__c ==''){
            component.set("v.errorMessage",'Please enter a primary contact');
            component.set("v.submitForm",false);
            return;
        }
        
        var selectedsdo =component.get("v.SelectedSDO");
        
        if(selectedsdo == '' || selectedsdo == undefined){
            fields.SDO__c=component.get("v.defaultSDO");
        }
        if(fields.Request_Type__c !='Disclose Patent/IP to SDO'){
            
            if(selectedsdo == '' || selectedsdo == undefined){
                console.log(fields.Long_Name__c);
                console.log(fields.Short_Name__c);
                if(fields.Long_Name__c != '' && fields.Long_Name__c != null){
                    var longname =fields.Long_Name__c;
                    var sdolist=component.get("v.SDO");
                    for(var i=0;i<sdolist.length;i++){
                        if(sdolist[i].Long_Name__c == longname){
                            console.log(sdolist[i].Id);
                            component.set("v.errorMessage",'This is an existing Standards Development Organization (SDO Long Name). Please use different SDO name(s) or select the existing SDO from the SDO Dropdown');
                            component.set("v.submitForm",false);
                            return;
                        }
                    }
                }
                /*if(fields.Short_Name__c ==null && fields.Long_Name__c == null){
                    component.set("v.errorMessage",'Please either select a value for the SDO from the dropdown or provide information on a New SDO not in the list');
                    component.set("v.submitForm",false);
                    return;
                }else if(fields.Short_Name__c ==null || fields.Short_Name__c == ''){
                    component.set("v.errorMessage",'Please enter short name for the SDO');
                    component.set("v.submitForm",false);
                    return;
                }else if(fields.Long_Name__c == null || fields.Long_Name__c == ''){
                    component.set("v.errorMessage",'Please enter long name for the SDO');
                    component.set("v.submitForm",false);
                    return;
                }else{
                    var longname =fields.Long_Name__c;
                    var sdolist=component.get("v.SDO");
                    for(var i=0;i<sdolist.length;i++){
                        if(sdolist[i].Long_Name__c == longname){
                            console.log(sdolist[i].Id);
                            component.set("v.errorMessage",'This is an existing Standards Development Organization (SDO Long Name). Please use different SDO name(s) or select the existing SDO from the SDO Dropdown');
                            component.set("v.submitForm",false);
                            return;
                        }
                    }
                }*/
            }   
        }
        
        console.log(component.get("v.Motivations"));
        var motivations=component.get("v.Motivations");
        var motivation='';
        for(var i=0;i<motivations.length;i++){
            motivation +=motivations[i] + ';';
        }
        fields.Motivation__c = motivation;
        console.log(motivation);
        
        
        var MembershipLevels=component.get("v.MembershipLevel");
        var MembershipLevel='';
        for(var i=0;i<MembershipLevels.length;i++){
            MembershipLevel +=MembershipLevels[i] + ';';
        }
        fields.Membership_Level__c = MembershipLevel;
        
        console.log(component.get("v.LeadershipPositions"));
        //return;
        /*if(fields.Request_Type__c =='Disclose Patent/IP to SDO' && (fields.SDO__c == null || fields.SDO__c == '') && component.get("v.hasAccess")){
            component.set("v.errorMessage",'SDO Should not be null');
            return;
        }else if(fields.Request_Type__c =='Form a New SDO' && (fields.Long_Name__c == null || fields.Long_Name__c == '') && (fields.Short_Name__c == null || fields.Short_Name__c == '')){
            component.set("v.errorMessage",'SDO Should not be null');
            return;
        }*/
        
        if(fields.Status__c == 'Draft'){
        	fields.Final_Decision__c = 'Draft';
        }
        
        if(fields.Request_Type__c == 'Disclose Patent/IP to SDO' || fields.Request_Type__c == 'Obtain/Implement a Technical Specification'){
            fields.SDOWG_Select__c = 'Not Applicable';
            fields.Leadership_Working_Group__c ='No';
            fields.Management_Review__c ='Standards Admin';
            fields.SDOWG_Select__c ='Not Applicable';
            fields.Working_Groups__c ='No';
            fields.Workflow_Status__c ='Standards IC Review';
            //IP_Manager__c 
        }
        
        if(fields.Request_Type__c =='Submit a Technical Contribution'){
            fields.Technical_Contribution__c ='Yes';
        }
       
        console.log('handleSubmit:::'+fields);
        component.find('save').submit(fields);
    },
    
    handeleexit : function(component, event, helper) {
        if(component.get("v.RequestStatus") == 'Draft'){
            helper.partialSave(component);
        }
        var homeEvent = $A.get("e.force:navigateToObjectHome");
        homeEvent.setParams({
            "scope": "Standard_Request__c"
        });
        homeEvent.fire();
    },handleclose : function(component, event, helper) {
       // helper.partialSave(component);
        var homeEvent = $A.get("e.force:navigateToObjectHome");
        homeEvent.setParams({
            "scope": "Standard_Request__c"
        });
        homeEvent.fire();
    },
    
    
    ManagementApprovalChange : function(component, event, helper) {
        console.log(component.get("v.ManagementApproval"));
        component.set("v.ManagementApprover",false);
        if(component.get("v.ManagementApproval") == 'Yes'){
        	component.set("v.ManagementApprover",true);
        }
        helper.partialSave(component);
    },
    
    handleClick : function(component, event, helper) {
    },
    
    handleChange : function(component, event, helper) {
    },
    
    handleSave : function(component, event, helper) {
        component.set("v.title","Apple Standards Request Draft");
        component.set("v.SaveClick",true);
    },
    
    handleApproverName : function(component, event, helper) {
        component.set("v.displayPopup",true);
    },
    
    handlecancel : function(component, event, helper) {
        component.set("v.displayPopup",false);
    },
    
    
    
    //******* Tooltip with +/- icon *******
    
    ExpandRowProjectCodeName : function(component, event, helper)
    {
        component.set('v.isPrimaryContactExpanded',true);
    },
    
    CollapseRowProjectCodeName : function(component, event, helper)
    {
        component.set('v.isPrimaryContactExpanded',false);
    },
     ExpandStandReqDoc : function(component, event, helper)
    {
        component.set('v.isStandReqDoc',true);
    },
    
    CollapseStandReqDoc : function(component, event, helper)
    {
        component.set('v.isStandReqDoc',false);
    },
    
    ExpandManagementApproval : function(component, event, helper)
    {
        component.set('v.isManagementApprovalExpanded',true);
    },
    
    CollapseManagementApproval : function(component, event, helper)
    {
        component.set('v.isManagementApprovalExpanded',false);
    },
    
    ExpandSDOName : function(component, event, helper)
    {
        component.set('v.isSDONameExpanded',true);
    },
    
    CollapseSDOName : function(component, event, helper)
    {        
        component.set('v.isSDONameExpanded',false);
    },
    
    ExpandSDOWGName : function(component, event, helper)
    {
        component.set('v.isSDOWGNameExpanded',true);
    },
    
    CollapseSDOWGName : function(component, event, helper)
    {        
        component.set('v.isSDOWGNameExpanded',false);
    },
    
    ExpandMembershipLevel : function(component, event, helper)
    {
        component.set('v.isMembershipLevelExpanded',true);
                
    },
     ExpandStandDeveOrg: function(component, event, helper)
    {
        component.set('v.isExpandStandDeveOrg',true);
                
    },
     CollapseStandDeveOrg: function(component, event, helper)
    {        
        component.set('v.isExpandStandDeveOrg',false);
    },
    ExpandSDOWGroup: function(component, event, helper)
    {
        component.set('v.isSDOWGroup',true);
                
    },
     CollapseSDOWGroup: function(component, event, helper)
    {        
        component.set('v.isSDOWGroup',false);
    },
    CollapseMembershipLevel : function(component, event, helper)
    {        
        component.set('v.isMembershipLevelExpanded',false);
    },
    
    ExpandOtherMembershipLevel : function(component, event, helper)
    {
        component.set('v.isOtherMembershipLevelExpanded',true);
    },
    
    CollapseOtherMembershipLevel : function(component, event, helper)
    {        
        component.set('v.isOtherMembershipLevelExpanded',false);
    },
    ExpandEstablishSDOWorkingGroup : function(component, event, helper)
    {
        component.set('v.isEstablishSDOWorkingGroupExpanded',true);
    },
    
    CollapseEstablishSDOWorkingGroup : function(component, event, helper)
    {        
        component.set('v.isEstablishSDOWorkingGroupExpanded',false);
    },
    
    ExpandMembershipLevelComments : function(component, event, helper)
    {
        component.set('v.isMembershipLevelCommentsExpanded',true);
    },
    
    CollapseMembershipLevelComments : function(component, event, helper)
    {        
        component.set('v.isMembershipLevelCommentsExpanded',false);        
    },
    
    ExpandLeadershipPosition : function(component, event, helper)
    {
        component.set('v.isLeadershipPositionExpanded',true);
    },
    
    CollapseLeadershipPosition : function(component, event, helper)
    {        
        component.set('v.isLeadershipPositionExpanded',false);
    },
    
    ExpandMotivation : function(component, event, helper)
    {
        component.set('v.isMotivationExpanded',true);
    },
    
    CollapseMotivation : function(component, event, helper)
    {        
        component.set('v.isMotivationExpanded',false);
    },
    
    ExpandBenefits : function(component, event, helper)
    {
        component.set('v.isBenefitsExpanded',true);
    },
    
    CollapseBenefits : function(component, event, helper)
    {        
        component.set('v.isBenefitsExpanded',false);
    },
    
    ExpandOtherCompany : function(component, event, helper)
    {
        component.set('v.isOtherCompanyExpanded',true);        
    },
    
    CollapseOtherCompany : function(component, event, helper)
    {        
        component.set('v.isOtherCompanyExpanded',false);
    },
    
    ExpandTechnologyAreas : function(component, event, helper)
    {
        component.set('v.isTechnologyAreasExpanded',true);
    },
    
    CollapseTechnologyAreas : function(component, event, helper)
    {        
        component.set('v.isTechnologyAreasExpanded',false);
    },
    ExpandCompeting : function(component, event, helper)
    {
      component.set('v.isCompetingExpanded',true);
    },
    CollapseCompeting : function(component, event, helper)
    {        
        component.set('v.isCompetingExpanded',false);
    },
    ExpandTechnologyArea : function(component, event, helper)
    {
       component.set('v.isTechnologyAreaExpanded',true);
    },
    CollapseTechnologyArea : function(component, event, helper)
    {        
        component.set('v.isTechnologyAreaExpanded',false);
    },
    ExpandTechinicalcontribution : function(component, event, helper)
    {
        component.set('v.isTechinicalcontributionExpanded',true);
    },
    CollapseTechinicalcontribution : function(component, event, helper)
    {        
        component.set('v.isTechinicalcontributionExpanded',false);
    },
    ExpandPatentCounsel : function(component, event, helper)
    {
        component.set('v.isPatentCounselExpanded',true);
    },
    CollapsePatentCounsel : function(component, event, helper)
    {        
        component.set('v.isPatentCounselExpanded',false);
    },
    ExpandDueDate : function(component, event, helper)
    {
       component.set('v.isDueDateExpanded',true);
    },
    CollapseDueDate : function(component, event, helper)
    {        
        component.set('v.isDueDateExpanded',false);
    },
    
    ExpandSDOTechnicalStandard : function(component, event, helper)
    {
        console.log('ExpandSDOTechnicalStandard');
       component.set('v.isSDOTechnicalStandardExpanded',true);
    },
    CollapseSDOTechnicalStandard : function(component, event, helper)
    {   
        console.log('CollapseSDOTechnicalStandard');
        component.set('v.isSDOTechnicalStandardExpanded',false);
    },
    
    ExpandTechnicalSpecification : function(component, event, helper)
    {
       component.set('v.isTechnicalSpecificationExpanded',true);
    },
    CollapseTechnicalSpecification : function(component, event, helper)
    {   
        component.set('v.isTechnicalSpecificationExpanded',false);
    },
    
    ExpandSpecificationImportance : function(component, event, helper)
    {
       component.set('v.isTechnicalSpecificationImportanceExpanded',true);
    },
    CollapseSpecificationImportance : function(component, event, helper)
    {   
        component.set('v.isTechnicalSpecificationImportanceExpanded',false);
    },
    ExpandLeadershipWG : function(component, event, helper)
    {
       component.set('v.isLeadershipWGExpanded',true);
    },
    CollapseLeadershipWG : function(component, event, helper)
    {   
        component.set('v.isLeadershipWGExpanded',false);
    },
    ExpandLegalClaims : function(component, event, helper)
    {
       component.set('v.isLegalClaimsExpanded',true);
    },
    CollapseLegalClaims : function(component, event, helper)
    {   
        component.set('v.isLegalClaimsExpanded',false);
    },
    ExpandIndemnification : function(component, event, helper)
    {
       component.set('v.isIndemnificationExpanded',true);
    },
    CollapseIndemnification : function(component, event, helper)
    {   
        component.set('v.isIndemnificationExpanded',false);
    },
    ExpandInvolvementExpanded : function(component, event, helper)
    {
       component.set('v.isSDOInvolvementExpanded',true);
    },
    CollapseInvolvementExpanded : function(component, event, helper)
    {   
        component.set('v.isSDOInvolvementExpanded',false);
    },
    ExpandLeadershipBenefits : function(component, event, helper)
    {
       component.set('v.isLeadershipBenefits',true);
    },
    CollapseLeadershipBenefits : function(component, event, helper)
    {   
        component.set('v.isLeadershipBenefits',false);
    },
    ExpandLeadershipConflicts : function(component, event, helper)
    {
       component.set('v.isLeadershipConflicts',true);
    },
    CollapseLeadershipConflicts : function(component, event, helper)
    {   
        component.set('v.isLeadershipConflicts',false);
    },
    ExpandTechnicalContribution : function(component, event, helper)
    {
       component.set('v.isTechnicalContributionExpanded',true);
    },
    CollapseTechnicalContribution : function(component, event, helper)
    {   
        component.set('v.isTechnicalContributionExpanded',false);
    },
    ExpandUpload : function(component, event, helper)
    {
       component.set('v.isuploadExpanded',true);
    },
    CollapseUpload : function(component, event, helper)
    {   
        component.set('v.isuploadExpanded',false);
    },
    ExpandJointCompanySubmission : function(component, event, helper)
    {
       component.set('v.isJointCompanySubmissionExpanded',true);
    },
    CollapseJointCompanySubmission : function(component, event, helper)
    {   
        component.set('v.isJointCompanySubmissionExpanded',false);
    },
    
    
    
    /*popups*/
    openWorkingGroups : function(component, event, helper)
    {   
        var SDO=component.get("v.SelectedSDO");
        if(SDO == '' || SDO == null || SDO == undefined){
            alert('Please Select Standard Development organizaiton to select Working groups');
            return;
        }
        console.log('SDO:::'+SDO);
        
        var action = component.get("c.fetchWorkingGroups");
        action.setParams({"sdoId":SDO});
        action.setCallback(this, function(response){
            var state = response.getState();
            var result = response.getReturnValue();
            console.log(result);
            if (state === "SUCCESS") 
            {
                console.log(result);
                if(result.length == 0){
                    alert('No working groups available for this SDO');
                    return;
                }else{
                    component.set("v.Workinggroups",result);
                    component.set('v.displayWorkingGroups',true);
                }
                
            }
        });
        $A.enqueueAction(action);
        
    },
    cancelWorkingGroups : function(component, event, helper)
    {   
        component.set('v.displayWorkingGroups',false);
    },
    
    savedisplayWorkingGroups : function(component, event, helper)
    {   
        console.log(component.get("v.selectedWorkinggroups"));
        var workingGroups=component.get("v.selectedWorkinggroups");
        if(workingGroups.length == 0){
            alert('Please select atleast 1 Working group');
            return;
        }
        
        var action = component.get("c.saveWorkingGroups");
        action.setParams({"recordId":component.get("v.recordId"),"workingGroups" : workingGroups});
        action.setCallback(this, function(response){
            var state = response.getState();
            var result = response.getReturnValue();
            console.log(result);
            if (result.errorMessage == '') 
            {
                console.log(result.errorMessage);
                component.set('v.SDOWgroups',result.lstResult);
                component.set('v.displayWorkingGroups',false);
                component.set("v.selectedWorkinggroups",[]);
            }else{
                console.log(result.errorMessage);
                return;
            }
        });
        $A.enqueueAction(action);
        
        
    },
    
     selectWorkinggroups: function(component, event, helper) {
         var workinggroups=component.get("v.selectedWorkinggroups");
         console.log(event.getSource().get('v.checked'));
         var selectedvalue=event.getSource().get('v.value');
         if(event.getSource().get('v.checked')){
             workinggroups.push(selectedvalue);
         }else{
             var index = workinggroups.indexOf(selectedvalue);
            if (index !== -1) {
              workinggroups.splice(index, 1);
            }
         }
         component.set("v.selectedWorkinggroups",workinggroups);
     },
    
    removeWorkinggroups : function(component, event, helper) {
        var workinggroups=component.get("v.removedWorkinggroups");
         console.log(event.getSource().get('v.checked'));
         var selectedvalue=event.getSource().get('v.value');
         if(event.getSource().get('v.checked')){
             workinggroups.push(selectedvalue);
         }else{
             var index = workinggroups.indexOf(selectedvalue);
            if (index !== -1) {
              workinggroups.splice(index, 1);
            }
         }
         component.set("v.removedWorkinggroups",workinggroups);
    },
    
    deleteWorkingGroup : function(component, event, helper) {
        var selectedvalue=event.getSource().get('v.value');
        console.log(selectedvalue);
        	var action = component.get("c.deleteWorkGroups");
            action.setParams({"recordId":selectedvalue});
            action.setCallback(this, function(response){
                var state = response.getState();
                var result = response.getReturnValue();
                console.log(result);
                if(result.errorMessage == ''){
                    var records=component.get("v.SDOWgroups");
                    for(var i=0;i<records.length;i++){
                        if(records[i].Id == selectedvalue){
                            records.splice(i, 1);
                            break;
                        }
                    }
                	component.set("v.SDOWgroups",records);
                }
                
            });
            $A.enqueueAction(action);
    },
    
     AddNewSDOWG : function(component, event, helper){        
        component.set("v.openSDOWGModal", true);
    },
    
    /*deleteWorkingGroups : function(component, event, helper) {
        	var workinggroups=component.get("v.removedWorkinggroups");
        	console.log(workinggroups);
        	var action = component.get("c.deleteWorkGroups");
            action.setParams({"recordId":component.get("v.recordId"),"workingGroups" : workinggroups});
            action.setCallback(this, function(response){
                var state = response.getState();
                var result = response.getReturnValue();
                console.log(result);
                if (result.errorMessage == '') 
                {
                    console.log(result.errorMessage);
                    component.set('v.SDOWgroups',result.lstResult);
                    component.set('v.displayWorkingGroups',false);
                    component.set("v.removedWorkinggroups",[]);
                }else{
                    console.log(result.errorMessage);
                    return;
                }
            });
            $A.enqueueAction(action);
    },*/
    
    /*Partipants pop up*/
    openParticipants : function(component, event, helper)
    {   
        var action = component.get("c.fetchParticipants");
        action.setCallback(this, function(response){
            var state = response.getState();
            var result = response.getReturnValue();
            console.log(result);
            if (state === "SUCCESS") 
            {
                console.log(result);
                component.set("v.lstPerson",result);
                component.set('v.displayParticipants',true);
            }
        });
        $A.enqueueAction(action);
        
    },
    cancelParticipants : function(component, event, helper)
    {   
        component.set('v.displayParticipants',false);
    },
    
    saveParticipants : function(component, event, helper)
    {   
        console.log(component.get("v.selectedparticipants"));
        var participants=component.get("v.selectedparticipants");
        if(participants.length == 0){
            alert('Please select atleast 1 participant');
            return;
        }
        
        var action = component.get("c.createparticipants");
        action.setParams({"recordId":component.get("v.recordId"),"participants" : participants});
        action.setCallback(this, function(response){
            var state = response.getState();
            var result = response.getReturnValue();
            console.log(result);
            if (result.errorMessage == '') 
            {
                console.log(result.errorMessage);
                component.set('v.participants',result.lstResult);
                component.set('v.displayParticipants',false);
                component.set("v.selectedparticipants",[]);
            }else{
                console.log(result.errorMessage);
                return;
            }
        });
        $A.enqueueAction(action);
        
        
    },
    
     selectParticipant: function(component, event, helper) {
         var workinggroups=component.get("v.selectedparticipants");
         console.log(event.getSource().get('v.checked'));
         var selectedvalue=event.getSource().get('v.value');
         if(event.getSource().get('v.checked')){
             workinggroups.push(selectedvalue);
         }else{
             var index = workinggroups.indexOf(selectedvalue);
            if (index !== -1) {
              workinggroups.splice(index, 1);
            }
         }
         component.set("v.selectedparticipants",workinggroups);
     },
    
    removeparticipant : function(component, event, helper) {
        var workinggroups=component.get("v.removedparticipants");
         console.log(event.getSource().get('v.checked'));
         var selectedvalue=event.getSource().get('v.value');
         if(event.getSource().get('v.checked')){
             workinggroups.push(selectedvalue);
         }else{
             var index = workinggroups.indexOf(selectedvalue);
            if (index !== -1) {
              workinggroups.splice(index, 1);
            }
         }
         component.set("v.removedparticipants",workinggroups);
    },
    
    /*deleteParticipants : function(component, event, helper) {
            var workinggroups=component.get("v.removedparticipants");
            console.log(workinggroups);
            var action = component.get("c.deleteparticipants");
            action.setParams({"recordId":component.get("v.recordId"),"participants" : workinggroups});
            action.setCallback(this, function(response){
                var state = response.getState();
                var result = response.getReturnValue();
                console.log(result);
                if (result.errorMessage == '') 
                {
                    console.log(result.errorMessage);
                    component.set('v.participants',result.lstResult);
                    component.set('v.displayParticipants',false);
                    component.set("v.removedparticipants",[]);
                }else{
                    console.log(result.errorMessage);
                    return;
                }
            });
            $A.enqueueAction(action);
    },*/
    
    deleteParticipant : function(component, event, helper) {
        var selectedvalue=event.getSource().get('v.value');
        console.log(selectedvalue);
        	var action = component.get("c.deleteparticipants");
            action.setParams({"recordId":selectedvalue});
            action.setCallback(this, function(response){
                var state = response.getState();
                var result = response.getReturnValue();
                console.log(result);
                if(result.errorMessage == ''){
                    var records=component.get("v.participants");
                    for(var i=0;i<records.length;i++){
                        if(records[i].Id == selectedvalue){
                            records.splice(i, 1);
                            break;
                        }
                    }
                	component.set("v.participants",records);
                }
                
            });
            $A.enqueueAction(action);
    },
    
    handleMarkImageUploadFinished : function(component, event, helper) {
        	var uploadedFiles = event.getParam("files");
        	
            var action = component.get("c.fetchDocuments");
            action.setParams({"recordId":component.get("v.recordId")});
            action.setCallback(this, function(response){
                var state = response.getState();
                var result = response.getReturnValue();
                console.log(result);
                component.set("v.Documents",result);
                component.set("v.DocsUploaded",true);
                window.setTimeout(
                    $A.getCallback(function() {
                        component.set("v.DocsUploaded",false);
                    }), 3000
                );
            });
            $A.enqueueAction(action);
    },
    
    deleteDoc : function(component, event, helper) {
        var selectedvalue=event.getSource().get('v.value');
        console.log(selectedvalue);
        var action = component.get("c.deleteDocument");
            action.setParams({"recordId":selectedvalue});
            action.setCallback(this, function(response){
                var state = response.getState();
                var result = response.getReturnValue();
                console.log(result);
                if(result.errorMessage == ''){
                    var docs=component.get("v.Documents");
                    for(var i=0;i<docs.length;i++){
                        if(docs[i].Id == selectedvalue){
                            docs.splice(i, 1);
                            break;
                        }
                    }
                	component.set("v.Documents",docs);
                }
                
            });
            $A.enqueueAction(action);
    },
    
    deleterecord : function(component, event, helper) {
        var action = component.get("c.deleteStandardRequest");
        action.setParams({"recordId":component.get("v.recordId")});
        action.setCallback(this, function(response){
            var state = response.getState();
            var result = response.getReturnValue();
            console.log(result);
            if(result.errorMessage == ''){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Success',
                    message:'Record deleted successfully',
                    duration:'500',
                    key: 'info_alt',
                    type: 'Success',
                    mode: 'pester'
                });
                toastEvent.fire();
                
                //   Navigate to home page
                var urlEvent = $A.get("e.force:navigateToURL"); urlEvent.setParams({ "url": "/lightning/page/home" }); urlEvent.fire();   
            }
            
        });
        $A.enqueueAction(action);
    },
    
    keyPressWorkingGroups : function(component, event, helper){
        console.log(component.get("v.searchWorkingGroups"));
        var isEscKey = event.keyCode === 27;
        if (isEscKey)
        {
            component.set('v.isShowSearchResultWorkingGroups',false);
            component.set("v.searchWorkingGroups", '');
            component.set("v.cmdAddSDOWG", false);
        }
        
        var getInputkeyWord = component.get("v.searchWorkingGroups");
        if(getInputkeyWord.length > 2 ){
            helper.getWorkingGroupsData(component,getInputkeyWord);
        }else{
            component.set("v.isShowSearchResultWorkingGroups", false);
        }
    },
    
    onblurWorkingGroups : function(component, event, helper) { 
        console.log('blur called::');
        
        component.set("v.isShowSearchResult", false );
        component.set("v.displayWorkingGroupstable", false );
        //component.set("v.cmdAddSDOWG", false);
        component.set("v.searchWorkingGroups", '');
        
        console.log(component.get("v.SDOWGdata"));
        var lstRecords=component.get("v.SDOWGdata");
        console.log(lstRecords);
        console.log(lstRecords.length);
        
        if(lstRecords.length > 0){
            
            var action = component.get("c.saveWorkingGroups");
        	action.setParams({"recordId":component.get("v.recordId"),"workingGroups" : lstRecords});
            action.setCallback(this,function(response){
                var state = response.getState();
                console.log(response.getReturnValue());
                var result=response.getReturnValue();
                
                if (result.errorMessage == '') 
                {
                    console.log(result.errorMessage);
                    component.set('v.SDOWgroups',result.lstResult);
                }else{
                    console.log(result.errorMessage);
                    return;
                }
                component.set("v.selectedkeyIds",[]);
                component.set("v.SDOWGdata",[]);
                
            });
            $A.enqueueAction(action);
        }
    },
    
    keyPressParticipants : function(component, event, helper){
        console.log(component.get("v.searchParticipants"));
        var isEscKey = event.keyCode === 27;
        if (isEscKey)
        {
            component.set('v.isShowSearchParticipantResult',false);
            component.set("v.searchParticipants", '');
        }
        
        var getInputkeyWord = component.get("v.searchParticipants");
        if(getInputkeyWord.length > 2 ){
            helper.getParticipantsData(component,getInputkeyWord);
        }else{
            component.set("v.isShowSearchParticipantResult", false);
        }
    },
    
    onblurParticipants : function(component, event, helper) { 
        console.log('blur called::');
        
        component.set("v.isShowSearchParticipantResult", false );
        component.set("v.displayParticipantstable", false );
        component.set("v.searchParticipants", '');
        
        console.log(component.get("v.participantsdata"));
        var lstRecords=component.get("v.participantsdata");
        console.log(lstRecords);
        console.log(lstRecords.length);
        
        if(lstRecords.length > 0){
            
            var action = component.get("c.createparticipants");
            action.setParams({"recordId":component.get("v.recordId"),"participants" : lstRecords});
            action.setCallback(this, function(response){
                var state = response.getState();
                var result = response.getReturnValue();
                console.log(result);
                component.set('v.participants',result);
                
                component.set("v.selectedParticipantkeyIds",[]);
                component.set("v.participantsdata",[]);
            });
            $A.enqueueAction(action);
        }
    },
    
    handleCloseSDOWGModal: function(component, event, helper) {
        //For Display Modal, Set the "openModal" attribute to "true"
        component.set("v.openSDOWGModal", false);
        component.set("v.searchWorkingGroups", '');
    },
    
    handleSDOWGSuccess : function(component, event, helper) {
        var record = event.getParam("response");
        var apiName = record.apiName;
        console.log(record.id);
        var action = component.get("c.saveWorkingGroupId");
        action.setParams({"recordId":component.get("v.recordId"),"sdowgId" : record.id});
        action.setCallback(this,function(response){
            var state = response.getState();
            console.log(response.getReturnValue());
            var result=response.getReturnValue();
            
            if (result.errorMessage == '') 
            {
                console.log(result.errorMessage);
                component.set('v.SDOWgroups',result.lstResult);
                component.set("v.openSDOWGModal", false);
            }else{
                console.log(result.errorMessage);
                return;
            }
        });
        $A.enqueueAction(action);
    },
    
    
    handleParticipantSuccess : function(component, event, helper) {
        var record = event.getParam("response");
        var apiName = record.apiName;
        console.log(record.id);
        var action = component.get("c.createparticipants");
        action.setParams({"recordId":component.get("v.recordId"),"participants" : []});
        action.setCallback(this,function(response){
            var state = response.getState();
            console.log(response.getReturnValue());
            var result=response.getReturnValue();
            component.set('v.participants',result);
            component.set("v.openParticipantModal",false);
        });
        $A.enqueueAction(action);
    },
    
    handleCloseParticipantModal : function(component, event, helper) {
        component.set("v.openParticipantModal",false);
    },
        
	handleRowAction : function(component, event, helper) { 
            //alert('fff'); 
            var action = event.getParam('SDOWgroups');
            var row = event.getParam('row');
            var rows = component.get('v.SDOWgroups')
            var rowIndex = rows.indexOf(row);
            var selectedvalue = rows[rowIndex].Id;
            console.log(selectedvalue);     
            var action = component.get("c.deleteWorkGroups");
            action.setParams({"recordId":selectedvalue});
            action.setCallback(this, function(response){
                var state = response.getState();
                var result = response.getReturnValue();
                console.log(result);
                if(result.errorMessage == ''){
                    var records=component.get("v.SDOWgroups");
                    for(var i=0;i<records.length;i++){
                        if(records[i].Id == selectedvalue){
                            records.splice(i, 1);
                            break;
                        }
                    }
                    component.set("v.SDOWgroups",records);
                }
                
            });
            $A.enqueueAction(action);
    },
        
	 handleSort: function(component, event, helper) {
        var sortedBy = event.getParam('fieldName');
        console.log(sortedBy);
        var sortDirection = event.getParam('sortDirection');
		console.log(sortDirection);
        var cloneData = component.get('v.SDOWgroups');
        cloneData.sort((helper.sortBy(sortedBy, sortDirection === 'asc' ? 1 : -1)));
        
        component.set('v.SDOWgroups', cloneData);
        component.set('v.sortDirection', sortDirection);
        component.set('v.sortedBy', sortedBy);
    },
    
    handleRowActionParticipants : function(component, event, helper) { 
            //alert('fff'); 
            var selectedaction = event.getParam('action');
        	var action = event.getParam('participants');
            var row = event.getParam('row');
            var rows = component.get('v.participants')
            var rowIndex = rows.indexOf(row);
            var selectedvalue = rows[rowIndex].Id;
            console.log(selectedvalue);     
        if(selectedaction.value == 'Edit'){
            console.log('update participant');
            component.set("v.participantId",selectedvalue);
            component.set("v.openParticipantModal",true);
        }else if(selectedaction.value == 'Delete'){
        
            var action = component.get("c.deleteparticipants");
        	action.setParams({"recordId":selectedvalue});
            action.setCallback(this, function(response){
                var state = response.getState();
                var result = response.getReturnValue();
                console.log(result);
                if(result.errorMessage == ''){
                    var records=component.get("v.participants");
                    for(var i=0;i<records.length;i++){
                        if(records[i].Id == selectedvalue){
                            records.splice(i, 1);
                            break;
                        }
                    }
                    component.set("v.participants",records);
                }
                
            });
            $A.enqueueAction(action);
            }
    },
    
    handleParticipantsSort: function(component, event, helper) {
        var sortedBy = event.getParam('fieldName');
        console.log(sortedBy);
        var sortDirection = event.getParam('sortDirection');
		console.log(sortDirection);
        var cloneData = component.get('v.participants');
        cloneData.sort((helper.sortBy(sortedBy, sortDirection === 'asc' ? 1 : -1)));
        
        component.set('v.participants', cloneData);
        component.set('v.sortDirection', sortDirection);
        component.set('v.sortedBy', sortedBy);
    },
    
    onclickSearch :function(component, event, helper) { 
        
            console.log('onclickSearch');
       
        if(component.get("v.SelectedSDO") != '' && component.get("v.SelectedSDO") != undefined){
           //alert('clickec');
            component.set("v.cmdAddSDOWG", false);
            helper.getFiltersData(component,component.get("v.SelectedSDO"));
            
        }
        else {
         //  alert("getFiltersDataOther");
            component.set("v.cmdAddSDOWG", false);
           helper.getFiltersDataOther(component,component.get("v.SelectedSDO")); 
        }
        
    },
    
    handlePrimaryInventorId :function(component, event, helper) { 
        console.log('event');
        var inventorID = event.getParam("LookupRecordId");
        var uniqueField=event.getParam("uniqueField");
        console.log('inventorID::'+inventorID);
        console.log(uniqueField);
        if(uniqueField =='Primary_Contact__c'){
            console.log(inventorID == '');
            console.log(inventorID);
            if(inventorID == ''){
                component.set('v.previouspInventor', component.get('v.pInventor'));
            }
            component.set('v.pInventor',inventorID);
            helper.populateAttorney(component);    
            var action = component.get("c.createparticipantsFromContact");
            action.setParams({"recordId":component.get("v.recordId"),"pcontactId":inventorID,"oldContact":component.get('v.previouspInventor')});
            action.setCallback(this, function(response){
                var state = response.getState();
                var result = response.getReturnValue();
                console.log(result);
                component.set("v.participants",result);
            });
            $A.enqueueAction(action);
        }else if(uniqueField =='Approver_Name__c'){
            component.set('v.approver', inventorID);
        }
        helper.partialSave(component);
        
        
    },
})