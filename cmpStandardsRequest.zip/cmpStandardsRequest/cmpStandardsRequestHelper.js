({
	displayFields : function(component,newValue) {
        
        console.log(newValue);
          
		component.set("v.JoinSDO",false);
        component.set("v.JoinSDOWorkingGroup",false);
        component.set("v.newSDO",false);
        component.set("v.EstablishSDOWorkingGroup",false);
        component.set("v.SubmitTechnicalContribution",false);
        component.set("v.ImplementTechnical",false);
        component.set("v.DiscloseSDO",false);
        component.set("v.SDOGovernance",false);
           component.set('v.isyesMailingLists','false');
      component.set("v.visibleSDOWGsearch",true);
        if(newValue == 'Disclose Patent/IP to SDO'){
            component.set("v.DiscloseSDO",true);
        }else if(newValue == 'Establish a New SDO Working Group'){
            component.set("v.EstablishSDOWorkingGroup",true);
            component.set("v.cmdAddSDOWG", true);
            component.set("v.visibleSDOWGsearch",false);
        }else if(newValue == 'Form a New SDO'){
            component.set("v.newSDO",true);
            component.set("v.SDOWGSelect1",'Yes');
            
        }else if(newValue == 'Join/Participate in Existing SDO Working Group'){
            component.set("v.JoinSDOWorkingGroup",true);
             //      component.set('v.MonitorMailingLists','Yes');
       //  component.set('v.isyesMailingLists','true');
      
        }else if(newValue == 'Join/Participate in Existing SDO'){
           //   component.set('v.MonitorMailingLists','Yes');
       //  component.set('v.isyesMailingLists','true');
      

            component.set("v.JoinSDO",true);
            component.set('v.SDOWGSelect','SubSet');
            component.set("v.displayWorkingGroups",true);
        }else if(newValue == 'Obtain/Implement a Technical Specification'){
            component.set("v.ImplementTechnical",true);
        }else if(newValue == 'Seek Appointment/Election to SDO Governance'){
            component.set("v.SDOGovernance",true);
        }else if(newValue == 'Submit a Technical Contribution'){
            component.set("v.SubmitTechnicalContribution",true);
            component.set("v.SDOWGSelect",'SubSet');
            component.set("v.displayWorkingGroups",true);
            //component.set("v.SelectedSDO",'true');
            
            
        }
	},
    
    partialSave : function(component){
        component.set("v.isPartialSave",true);
        component.find('save').submit();
    },
    
    populateAttorney : function (component){
        var action = component.get("c.assignAttorney");
        action.setParams({"recordId":component.get("v.pInventor")});
        action.setCallback(this, function(response){
            var state = response.getState();
            var result = response.getReturnValue();
            console.log(result);
            if (state === "SUCCESS") 
            {
                console.log('response::'+result);
                if(!result.startsWith('Error')){
                	component.set("v.attorney",result);   
				}
                
            }
        });
        $A.enqueueAction(action);
    }, populateIPManager : function (component){
        var action = component.get("c.IPManager");
        action.setParams({"recordId":component.get("v.pInventor")});
        action.setCallback(this, function(response){
            var state = response.getState();
            var result = response.getReturnValue();
            console.log(result);
            if (state === "SUCCESS") 
            {
                console.log('response::'+result);
                if(!result.startsWith('Error')){
                	component.set("v.IPManager",result);   
				}
                
            }
        });
        $A.enqueueAction(action);
    },
    
    getWorkingGroupsData : function (component,selectedvalue){
        console.log('selectedvalue::'+selectedvalue);
        var action = component.get("c.fetchWorkingGroupLookUpValues");
       // alert(component.get("v.SelectedSDO"))
        action.setParams({'searchGroup': selectedvalue,'sdoId': component.get("v.SelectedSDO")});
        
        //alert("getWorkingGroupsData " + component.get("v.SelectedSDO"));
        
            action.setCallback(this, function(response) {
                var state = response.getState();
                //alert("getWorkingGroupsData -  " + state);
                
                  if (state === "SUCCESS") {
                      
                    var storeResponse = response.getReturnValue();
                    $("#tblworkingGroups tr").remove();
                    var fieldsForSearch =storeResponse;   
                    console.log(storeResponse);
                      
                      if (fieldsForSearch.length > 0) {
                    
                          for(var i=0; i<fieldsForSearch.length;i++)
                   			 {
                        		var tblrow="<tr><td><span>"+fieldsForSearch[i].label+"</span>";
                        		tblrow = tblrow + "<input type='hidden' value='" + JSON.stringify(fieldsForSearch[i].obj) +"'/></td></tr>";                    
                        		$("#tblworkingGroups tbody").append(tblrow); 
                    		}
					//console.log($("#tblInventors"));
					$("#tblworkingGroups").highlight(selectedvalue);  
                    
                    $("#tblworkingGroups tr").on('click', 'td', function() {
                       var selectedInventorID= $(this).parents('tr').find('input[type="hidden"]').val();   
                       var listSelectedInvs = JSON.parse(decodeURIComponent(selectedInventorID));
                       var invID=listSelectedInvs;
                       var selectid =invID.Id;
                        console.log(selectid);
                        var lstkeyIds=component.get("v.selectedkeyIds");
                        lstkeyIds.push({"key":invID.Alias__c + '-' +invID.Title__c,"value" :selectid});
                        component.set("v.selectedkeyIds",lstkeyIds);
                        
                        //console.log(component.get("v.selectedkeyIds"));
                        var tabledata = component.get("v.SDOWGdata");
                        tabledata.push(listSelectedInvs);
                        component.set("v.SDOWGdata",tabledata);
                        if(lstkeyIds.length >0){
                        	component.set("v.displayWorkingGroupstable",true);
                            component.set("v.cmdAddSDOWG", false);
                        }
                        $(this).parents('tr').remove();
                    }); 
                          
                      }
                    
                    
                      
                    //----- if storeResponse size is equal 0 ,display No Records Found... message on screen.                
                    if (fieldsForSearch.length == 0) {
                        //alert("getWorkingGroupsData");
                        
                        //component.set("v.cmdAddSDOWG", true);
                        
                        var tblrow="<tr><td><center>"+'No records found...'+"<br/><a>"+'Click here to add new SDO Working Group'+"</a></center></td></tr>";
                        $("#tblworkingGroups tbody").append(tblrow);
                        $("#tblworkingGroups").on('click', 'a', function() {
                            component.set("v.openSDOWGModal", true);
                        });
                        
                    } else {
                        component.set("v.Message", '');
                        // set searchResult list with return value from server.
                    }
                    component.set("v.isShowSearchResult", true);
                }
                else{
                var errors = response.getError();
                           if (errors)
                           {
                               if (errors[0] && errors[0].message)
                               {
                                    alert(errors[0].message );//Fetching Custom Message.
                               }
                           }
                }
            });
            
            // enqueue the Action  
            $A.enqueueAction(action);
    },
    
    getParticipantsData : function (component,selectedvalue){
        console.log('selectedvalue::'+selectedvalue);
        var action = component.get("c.fetchParticipantLookUpValues");
            action.setParams({'searchParticipant': selectedvalue});
            action.setCallback(this, function(response) {
                var state = response.getState();
                  if (state === "SUCCESS") {
                    var storeResponse = response.getReturnValue();
                    $("#tblParticipants tr").remove();
                    var fieldsForSearch =storeResponse;   
                      console.log(storeResponse);
                    for(var i=0; i<fieldsForSearch.length;i++)
                    {
                        var tblrow="<tr><td><span>"+fieldsForSearch[i].label+"</span>";
                        tblrow = tblrow + "<input type='hidden' value='" + JSON.stringify(fieldsForSearch[i].obj) +"'/></td></tr>";                    
                        $("#tblParticipants tbody").append(tblrow); 
                    }
					//console.log($("#tblInventors"));
					$("#tblParticipants").highlight(selectedvalue);  
                    
                    $("#tblParticipants tr").on('click', 'td', function() {
                       var selectedInventorID= $(this).parents('tr').find('input[type="hidden"]').val();   
                       var listSelectedInvs = JSON.parse(decodeURIComponent(selectedInventorID));
                       var invID=listSelectedInvs;
                       var selectid =invID.Id;
                        console.log(selectid);
                        var lstkeyIds=component.get("v.selectedParticipantkeyIds");
                        lstkeyIds.push({"key":invID.Name + '-' +invID.Preferred_Name__c,"value" :selectid});
                        component.set("v.selectedParticipantkeyIds",lstkeyIds);
                        //console.log(component.get("v.selectedkeyIds"));
                        var tabledata = component.get("v.participantsdata");
                        tabledata.push(listSelectedInvs);
                        component.set("v.participantsdata",tabledata);
                        if(lstkeyIds.length >0){
                        	component.set("v.displayParticipantstable",true);
                        }
                        $(this).parents('tr').remove();
                    }); 
                    //----- if storeResponse size is equal 0 ,display No Records Found... message on screen.                
                    if (fieldsForSearch.length == 0) {
                        component.set("v.Message", 'No records found...If you cannot find the person you are looking for,');
                        
                        var message=component.get("v.Message");
                        var tblrow="<tr><td><center>"+message+"<br/>"+'No Records Found'+"</center></td></tr>";
                        $("#tblParticipants tbody").append(tblrow);
                         
                    } else {
                        component.set("v.Message", '');
                        // set searchResult list with return value from server.
                    }
                    component.set("v.isShowSearchParticipantResult", true);
                }
                else{
                var errors = response.getError();
                           if (errors)
                           {
                               if (errors[0] && errors[0].message)
                               {
                                    alert(errors[0].message );//Fetching Custom Message.
                               }
                           }
                }
            });
            
            // enqueue the Action  
            $A.enqueueAction(action);
    },
    
    sortBy: function(field, reverse, primer) {
        var key = primer
            ? function(x) {
                  return primer(x[field]);
              }
            : function(x) {
                  return x[field];
              };

        return function(a, b) {
            a = key(a);
            b = key(b);
            return reverse * ((a > b) - (b > a));
        };
    },
    
    getFiltersData: function (component,SelectedSDO){
        var action = component.get("c.fetchWorkingGroupsonSelect");
        action.setParams({'sdoId': SelectedSDO});
            action.setCallback(this, function(response) {
                var state = response.getState();
                  if (state === "SUCCESS") {
                    var storeResponse = response.getReturnValue();
                    $("#tblworkingGroups tr").remove();
                    var fieldsForSearch =storeResponse;   
                      console.log(storeResponse);
                    for(var i=0; i<fieldsForSearch.length;i++)
                    {
                        var tblrow="<tr><td><span>"+fieldsForSearch[i].label+"</span>";
                        tblrow = tblrow + "<input type='hidden' value='" + JSON.stringify(fieldsForSearch[i].obj) +"'/></td></tr>";                    
                        $("#tblworkingGroups tbody").append(tblrow); 
                    }
                    console.log('1');
					//console.log($("#tblInventors"));
					
                    
                    $("#tblworkingGroups tr").on('click', 'td', function() {
                       var selectedInventorID= $(this).parents('tr').find('input[type="hidden"]').val();   
                       var listSelectedInvs = JSON.parse(decodeURIComponent(selectedInventorID));
                       var invID=listSelectedInvs;
                       var selectid =invID.Id;
                        console.log(selectid);
                        var lstkeyIds=component.get("v.selectedkeyIds");
                        lstkeyIds.push({"key":invID.Name + '-' +invID.Title__c,"value" :selectid});
                        component.set("v.selectedkeyIds",lstkeyIds);
                        //console.log(component.get("v.selectedkeyIds"));
                        var tabledata = component.get("v.SDOWGdata");
                        tabledata.push(listSelectedInvs);
                        component.set("v.SDOWGdata",tabledata);
                        if(lstkeyIds.length >0){
                        	component.set("v.displayWorkingGroupstable",true);
                            component.set("v.cmdAddSDOWG", false);
                        }
                        $(this).parents('tr').remove();
                    }); 
                    //----- if storeResponse size is equal 0 ,display No Records Found... message on screen.                
                    if (fieldsForSearch.length == 0) {
                        
                        //alert("getFiltersData");
                        //component.set("v.cmdAddSDOWG", true);
                        
                        var tblrow="<tr><td><center>"+'No records found...'+"<br/><a>"+'Click here to add new SDO Working Group'+"</a></center></td></tr>";
                        $("#tblworkingGroups tbody").append(tblrow); 
                        $("#tblworkingGroups").on('click', 'a', function() {
                            component.set("v.openSDOWGModal", true);
                        });
                        
                        
                    } else {
                        component.set("v.Message", '');
                        // set searchResult list with return value from server.
                    }
                    component.set("v.isShowSearchResult", true);
                }
                else{
                var errors = response.getError();
                           if (errors)
                           {
                               if (errors[0] && errors[0].message)
                               {
                                    alert(errors[0].message );//Fetching Custom Message.
                               }
                           }
                }
            });
            
            // enqueue the Action  
            $A.enqueueAction(action);
    },
    
    getFiltersDataOther: function (component,SelectedSDO){
        var action = component.get("c.fetchWorkingGroupsonOther");
        console.log( JSON.stringify(component.get("v.SDOWgroups")))
        action.setParams({'sdoId': SelectedSDO});
            action.setCallback(this, function(response) {
                var state = response.getState();
                  if (state === "SUCCESS") {
                    var storeResponse = response.getReturnValue();
                    $("#tblworkingGroups tr").remove();
                    var fieldsForSearch =storeResponse;   
                      console.log(storeResponse);
                    for(var i=0; i<fieldsForSearch.length;i++)
                    {
                        var tblrow="<tr><td><span>"+fieldsForSearch[i].label+"</span>";
                        tblrow = tblrow + "<input type='hidden' value='" + JSON.stringify(fieldsForSearch[i].obj) +"'/></td></tr>";                    
                        $("#tblworkingGroups tbody").append(tblrow); 
                    }
                    console.log('1');
					//console.log($("#tblInventors"));
					
                    
                    $("#tblworkingGroups tr").on('click', 'td', function() {
                       var selectedInventorID= $(this).parents('tr').find('input[type="hidden"]').val();   
                       var listSelectedInvs = JSON.parse(decodeURIComponent(selectedInventorID));
                       var invID=listSelectedInvs;
                       var selectid =invID.Id;
                        console.log(selectid);
                        var lstkeyIds=component.get("v.selectedkeyIds");
                        lstkeyIds.push({"key":invID.Name + '-' +invID.Title__c,"value" :selectid});
                        component.set("v.selectedkeyIds",lstkeyIds);
                        //console.log(component.get("v.selectedkeyIds"));
                        var tabledata = component.get("v.SDOWGdata");
                        tabledata.push(listSelectedInvs);
                        component.set("v.SDOWGdata",tabledata);
                        if(lstkeyIds.length >0){
                        	component.set("v.displayWorkingGroupstable",true);
                            component.set("v.cmdAddSDOWG", false);
                        }
                        $(this).parents('tr').remove();
                    }); 
                    //----- if storeResponse size is equal 0 ,display No Records Found... message on screen.                
                    if (fieldsForSearch.length == 0) {
                        //alert("Other");
                        //component.set("v.cmdAddSDOWG", true);
                        
                        var tblrow="<tr><td><center>"+'No records found...'+"<br/><a>"+'Click here to add new SDO Working Group'+"</a></center></td></tr>";
                        $("#tblworkingGroups tbody").append(tblrow);
                        $("#tblworkingGroups").on('click', 'a', function() {
                            component.set("v.openSDOWGModal", true);
                        });
                        
                        
                    } else {
                        component.set("v.Message", '');
                        // set searchResult list with return value from server.
                    }
                    component.set("v.isShowSearchResult", true);
                }
                else{
                var errors = response.getError();
                           if (errors)
                           {
                               if (errors[0] && errors[0].message)
                               {
                                    alert(errors[0].message );//Fetching Custom Message.
                               }
                           }
                }
            });
            
            // enqueue the Action  
            $A.enqueueAction(action);
    },
    
    populateInternalParticipant : function (component){
        console.log('populateInternalParticipant');
        console.log(component.get("v.recordId"));
        console.log(component.get('v.pInventor'));
        var action = component.get("c.createparticipantsFromContact");
        action.setParams({"recordId":component.get("v.recordId"),"pcontactId":component.get('v.pInventor'),"oldContact":null});
        action.setCallback(this, function(response){
            var state = response.getState();
            var result = response.getReturnValue();
            console.log(result);
            component.set("v.participants",result);
        });
        $A.enqueueAction(action);
    },
    
})