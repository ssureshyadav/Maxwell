({
    loadRecords : function(component, event, helper){
        /*var action = component.get('c.fetchRecords'); 
        
        
        action.setParams({
            objName : component.get("v.objName"),
            fieldSetName : component.get("v.fieldSetName"),
            relationshipField : component.get("v.relationshipField"),
            recordId : component.get("v.recordId")
        });
        
        action.setCallback(this, function(response){
            //store state of response
            var state = response.getState();
            if (state === "SUCCESS") {
                //alert(response.getReturnValue());
                var respMsg=response.getReturnValue();
                component.set('v.lstRecords', respMsg);
            }
        });
        $A.enqueueAction(action);*/
        
    },
    
    download : function(component,event,helper){
        
        var pagename =window.location.href.split('/')[5];
        var recordid = component.get("v.recordId");
        var objectRecords='';
        component.set("v.displaybar",true);
        component.set("v.progress",30); 
        
        var action = component.get('c.fetchRecords');         
        action.setParams({
            objName : component.get("v.objName"),
            fieldSetName : component.get("v.fieldSetName"),
            relationshipField : component.get("v.relationshipField"),
            recordId : component.get("v.recordId")
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            
            if (state === "SUCCESS") {
                var respMsg=response.getReturnValue();
                var objectRecords = respMsg.lstRecords;
                var fields = respMsg.mapFields;
                
                if (!objectRecords.length >0){
                    component.set("v.progress",100);
                    window.setTimeout(function(){ 
                        component.set("v.displaybar",false);
                    }, 100);
                    return;
                } 
                
                var csvStringResult, counter, keys, columnDivider, lineDivider;
                columnDivider = ',';
                lineDivider =  '\n';
                var fieldLabels=[];
                for(var key in fields){
                    fieldLabels.push(fields[key]);
                }
                console.log(fieldLabels);
                
                csvStringResult = '';
                csvStringResult += '"'+ fieldLabels.join('"'+columnDivider+'"') + '"';
                csvStringResult += lineDivider;
                
                for(var i=0; i < objectRecords.length; i++) {   
                    counter = 0;
                    console.log(objectRecords[i]);
                    for(var key in fields){
                        if(counter > 0){ 
                            csvStringResult += columnDivider; 
                        }   
                        console.log(key);
                        if(key.includes('.')){
                            console.log(key);
                            var fieldsSplit=key.split('.');
                            //console.log(fieldsSplit);
                            if(fieldsSplit.length == 2){
                            csvStringResult += '"'+ (objectRecords[i][fieldsSplit[0]][fieldsSplit[1]] != undefined ?objectRecords[i][fieldsSplit[0]][fieldsSplit[1]]:'') +'"';
                            }else if(fieldsSplit.length == 3){
                            csvStringResult += '"'+ (objectRecords[i][fieldsSplit[0]][fieldsSplit[1]] != undefined ?objectRecords[i][fieldsSplit[0]][fieldsSplit[1]][fieldsSplit[2]]:'') +'"';
                            }
                        }else{
                            if(objectRecords[i][key] != undefined){
                                //var output=objectRecords[i][key].replace(/\"/g,"\\\"");
                                //console.log(output);
                                csvStringResult +=  '"' + objectRecords[i][key] + '"';
                            }else{
                                csvStringResult += '"'+ '' +'"';
                            }
                            /*var output=objectRecords[i][key].replace(/\"/g,"\\\"");
                            console.log(output);
                            csvStringResult += '"'+ (objectRecords[i][key] != undefined ?output:'') +'"'; */
                        }
                        //console.log(objectRecords[i]);
                        
                        counter++;
                        
                    } 
                    csvStringResult += lineDivider;
                }
                
                window.setTimeout(function() { 
                    csvStringResult = csvStringResult.replaceAll("#", "Number");
                    // ####--code for create a temp. <a> html tag [link tag] for download the CSV file--####     
                    var hiddenElement = document.createElement('a');
                    hiddenElement.href = 'data:text/csv;utf-8,' + encodeURI(csvStringResult);
                    hiddenElement.target = '_self'; // 
                    hiddenElement.download = component.get("v.DownLoadFileName") + '.csv';  // CSV file Name* you can change it.[only name not .csv] 
                    document.body.appendChild(hiddenElement); // Required for FireFox browser
                    component.set("v.progress",100);
                                  
                    hiddenElement.click(); // using click() js function to download csv file
                    window.setTimeout(function(){ 
                        component.set("v.displaybar",false);
                    }, 2000);
                }, 1000);
                
                return csvStringResult; 
                
            }
            else {
                component.set("v.progress",100);
                window.setTimeout(function(){ 
                    component.set("v.displaybar",false);
                }, 100);
                return;
            }
        });
        $A.enqueueAction(action);
    },
})